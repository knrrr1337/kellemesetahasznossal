import './App.css';
import Header from "./Components/Header/Header.jsx";
import React, { useState } from "react"; // Ensure useState is imported
import Home from './Components/Body/Home.jsx';
import Raimund from './Components/Body/Mink/Raimund.jsx'; // Import Raimund component
import ßabolcs from './Components/Body/Mink/ßabolcs.jsx';
import References from './Components/Body/Mink/References.jsx';

function App() {
    const [page, setPage] = useState("Home"); // Declare state for the page

    return (
        <>
            <Header setPage={setPage} /> {/* Pass setPage to Header */}
            <main>
                {page === "Home" && <Home />}
                {page === "Raimund" && <Raimund />}
                {page === "ßabolcs" && <ßabolcs />}
                {page === "References" && <References />}
            </main>
        </>
    );
}

export default App;