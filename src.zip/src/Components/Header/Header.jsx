import "./Header.css";
import Raimund from "../Body/Mink/Raimund.jsx";
import Main from "../Body/Home.jsx";
import React, {useState} from "react";

function Header({ setPage }) {
    return (
        <>
            <header className="header">
                <div className="headerContainer">
                    <ul>
                        <li className="listItem" onClick={() => setPage("Home")}><a>Home Page</a></li>
                        <li className="listItem" onClick={() => setPage("Raimund")}><a>Raimund</a></li>
                        <li className="listItem" onClick={() => setPage("ßabolcs")}><a>ßabolcs</a></li>
                    </ul>
                    <ul>
                        <li className="listItem" onClick={() => setPage("References")}><a>References</a></li>
                    </ul>
                </div>
            </header>
        </>
    );
}

export default Header;