import "../Body.css";
import "../../Header/Header.css";
import "./profile.css";
import bigebozo from "../../resources/bigebozo.png";

function Raimund() {
    return(
        <div className="mainContainer-profile">
            <div className="content">
                <div className="asd">
                    <h1 className="policeFont mainTitle">ELFOGATÓ PARANCS ALAPJÁN KÖRÖZÖTT SZEMÉLY</h1>
                </div>
                <div className="feljelentes">
                    <p className="policeFont bejelentesP">Felismeri? Tegyen bejelentést!</p>
                </div>
                <div className="row">
                    <div className="photoDiv">
                        <img src={bigebozo} alt="" />
                    </div>
                    <div className="info">
                        <ul className="policeFont">
                            <li><b>Személyes adatok</b></li>
                            <li><b>Név:</b> BIGE RAJMUND</li>
                            <li><b>Születési családi és utonév:</b> BIGE RAJMUND</li>
                            <li><b>Nem:</b> Férfi</li>
                            <li><b>Születési hely:</b> NYÍREGYHÁZA</li>
                            <li><b>Születési dátum:</b>2005-02-19</li>
                            <li><b>Állampolgárság:</b> MAGYAR</li>
                        </ul>
                    </div>
                </div>
                
                
            </div>
            
        </div>
    );
}

export default Raimund;