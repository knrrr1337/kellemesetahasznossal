import "../Body.css";
import "../../Header/Header.css";

function ßabolcs() {
    return (
        <div className="mainContainer">break sumn</div>
    );
}

export default ßabolcs;