import "../Body.css";
import "../../Header/Header.css";

function References() {
    return(
        <>belo</>
    );
}

export default References;