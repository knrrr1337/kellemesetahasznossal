import "./Body.css";
import kep1 from "../resources/kep1.jpg";
import kep2 from "../resources/kep2.jpg";

function Home() {
    return(
        <>
        <div className="mainContainer">
            <h1>Helo</h1>
            <p>Ez az oldal, ahogy a projekt neve is indikálja, összeköti a kellemeset a hasznossal. Szakmai angol nevű tantárgyból
                is kell egy weboldalt készíteni HTML, CSS és JavaScript felhasználásával. Így csoporttársammal, Csatlós Szabolccsal 
                úgy döntöttünk, hogy két legyet egy csapásra ütünk le.
            </p>
            <div className="imgContainer">
                <img src={kep1} alt="" />
                <img src={kep2} alt="" />
            </div>
            
        </div>
        </>
    );
}


export default Home;